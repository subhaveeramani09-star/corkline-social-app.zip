const express = require('express');
const db = require('../db/database');
const { requireAuth } = require('../middleware/auth');

const router = express.Router();

// GET /api/posts/:postId/comments
router.get('/:postId/comments', (req, res) => {
  const post = db.prepare('SELECT id FROM posts WHERE id = ?').get(req.params.postId);
  if (!post) return res.status(404).json({ error: 'post not found' });

  const comments = db.prepare(
    `SELECT c.id, c.content, c.created_at,
            u.id AS user_id, u.username, u.display_name, u.avatar_url
     FROM comments c JOIN users u ON u.id = c.user_id
     WHERE c.post_id = ? ORDER BY c.created_at ASC`
  ).all(req.params.postId);

  res.json(comments);
});

// POST /api/posts/:postId/comments
router.post('/:postId/comments', requireAuth, (req, res) => {
  const post = db.prepare('SELECT id FROM posts WHERE id = ?').get(req.params.postId);
  if (!post) return res.status(404).json({ error: 'post not found' });

  const { content } = req.body;
  if (!content || !content.trim()) {
    return res.status(400).json({ error: 'content is required' });
  }

  const result = db.prepare(
    'INSERT INTO comments (post_id, user_id, content) VALUES (?, ?, ?)'
  ).run(req.params.postId, req.userId, content.trim());

  const comment = db.prepare(
    `SELECT c.id, c.content, c.created_at,
            u.id AS user_id, u.username, u.display_name, u.avatar_url
     FROM comments c JOIN users u ON u.id = c.user_id WHERE c.id = ?`
  ).get(result.lastInsertRowid);

  res.status(201).json(comment);
});

module.exports = router;

const standaloneRouter = express.Router();

standaloneRouter.delete('/:id', requireAuth, (req, res) => {
  const comment = db.prepare('SELECT * FROM comments WHERE id = ?').get(req.params.id);
  if (!comment) return res.status(404).json({ error: 'comment not found' });
  if (comment.user_id !== req.userId) {
    return res.status(403).json({ error: 'not your comment' });
  }

  db.prepare('DELETE FROM comments WHERE id = ?').run(req.params.id);
  res.json({ deleted: true });
});

module.exports.standaloneRouter = standaloneRouter;
