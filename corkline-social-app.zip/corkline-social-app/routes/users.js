const express = require('express');
const db = require('../db/database');
const { requireAuth, optionalAuth } = require('../middleware/auth');

const router = express.Router();

function getProfile(userId, viewerId) {
  const user = db.prepare(
    `SELECT id, username, email, display_name, bio, avatar_url, created_at
     FROM users WHERE id = ?`
  ).get(userId);

  if (!user) return null;

  const followerCount = db.prepare(
    'SELECT COUNT(*) AS c FROM follows WHERE following_id = ?'
  ).get(userId).c;

  const followingCount = db.prepare(
    'SELECT COUNT(*) AS c FROM follows WHERE follower_id = ?'
  ).get(userId).c;

  const postCount = db.prepare(
    'SELECT COUNT(*) AS c FROM posts WHERE user_id = ?'
  ).get(userId).c;

  let isFollowing = false;
  if (viewerId) {
    isFollowing = !!db.prepare(
      'SELECT 1 FROM follows WHERE follower_id = ? AND following_id = ?'
    ).get(viewerId, userId);
  }

  return { ...user, followerCount, followingCount, postCount, isFollowing };
}

// GET /api/users/:id - view a profile
router.get('/:id', optionalAuth, (req, res) => {
  const profile = getProfile(Number(req.params.id), req.userId);
  if (!profile) return res.status(404).json({ error: 'user not found' });
  res.json(profile);
});

// PUT /api/users/me - update own profile
router.put('/me', requireAuth, (req, res) => {
  const { display_name, bio, avatar_url } = req.body;

  db.prepare(
    `UPDATE users SET
       display_name = COALESCE(?, display_name),
       bio = COALESCE(?, bio),
       avatar_url = COALESCE(?, avatar_url)
     WHERE id = ?`
  ).run(display_name, bio, avatar_url, req.userId);

  res.json(getProfile(req.userId, req.userId));
});

// GET /api/users/:id/followers
router.get('/:id/followers', (req, res) => {
  const followers = db.prepare(
    `SELECT u.id, u.username, u.display_name, u.avatar_url
     FROM follows f JOIN users u ON u.id = f.follower_id
     WHERE f.following_id = ? ORDER BY f.created_at DESC`
  ).all(req.params.id);
  res.json(followers);
});

// GET /api/users/:id/following
router.get('/:id/following', (req, res) => {
  const following = db.prepare(
    `SELECT u.id, u.username, u.display_name, u.avatar_url
     FROM follows f JOIN users u ON u.id = f.following_id
     WHERE f.follower_id = ? ORDER BY f.created_at DESC`
  ).all(req.params.id);
  res.json(following);
});

// POST /api/users/:id/follow - follow a user
router.post('/:id/follow', requireAuth, (req, res) => {
  const targetId = Number(req.params.id);
  if (targetId === req.userId) {
    return res.status(400).json({ error: 'cannot follow yourself' });
  }

  const target = db.prepare('SELECT id FROM users WHERE id = ?').get(targetId);
  if (!target) return res.status(404).json({ error: 'user not found' });

  try {
    db.prepare('INSERT INTO follows (follower_id, following_id) VALUES (?, ?)')
      .run(req.userId, targetId);
  } catch (err) {
    return res.status(409).json({ error: 'already following' });
  }

  res.status(201).json({ following: true });
});

// DELETE /api/users/:id/follow - unfollow a user
router.delete('/:id/follow', requireAuth, (req, res) => {
  const targetId = Number(req.params.id);
  const result = db.prepare(
    'DELETE FROM follows WHERE follower_id = ? AND following_id = ?'
  ).run(req.userId, targetId);

  if (result.changes === 0) {
    return res.status(404).json({ error: 'not following this user' });
  }
  res.json({ following: false });
});

module.exports = router;
