const express = require('express');
const db = require('../db/database');
const { requireAuth, optionalAuth } = require('../middleware/auth');

const router = express.Router();

function attachMeta(posts, viewerId) {
  return posts.map(post => {
    const likeCount = db.prepare(
      'SELECT COUNT(*) AS c FROM likes WHERE post_id = ?'
    ).get(post.id).c;

    const commentCount = db.prepare(
      'SELECT COUNT(*) AS c FROM comments WHERE post_id = ?'
    ).get(post.id).c;

    let likedByMe = false;
    if (viewerId) {
      likedByMe = !!db.prepare(
        'SELECT 1 FROM likes WHERE post_id = ? AND user_id = ?'
      ).get(post.id, viewerId);
    }

    return { ...post, likeCount, commentCount, likedByMe };
  });
}

// GET /api/posts - global feed, or ?feed=following for posts by people you follow
router.get('/', optionalAuth, (req, res) => {
  let posts;

  if (req.query.feed === 'following' && req.userId) {
    posts = db.prepare(
      `SELECT p.id, p.content, p.image_url, p.created_at,
              u.id AS user_id, u.username, u.display_name, u.avatar_url
       FROM posts p
       JOIN users u ON u.id = p.user_id
       WHERE p.user_id IN (
         SELECT following_id FROM follows WHERE follower_id = ?
       ) OR p.user_id = ?
       ORDER BY p.created_at DESC LIMIT 50`
    ).all(req.userId, req.userId);
  } else {
    posts = db.prepare(
      `SELECT p.id, p.content, p.image_url, p.created_at,
              u.id AS user_id, u.username, u.display_name, u.avatar_url
       FROM posts p
       JOIN users u ON u.id = p.user_id
       ORDER BY p.created_at DESC LIMIT 50`
    ).all();
  }

  res.json(attachMeta(posts, req.userId));
});

// GET /api/posts/user/:userId - all posts by a specific user
router.get('/user/:userId', optionalAuth, (req, res) => {
  const posts = db.prepare(
    `SELECT p.id, p.content, p.image_url, p.created_at,
            u.id AS user_id, u.username, u.display_name, u.avatar_url
     FROM posts p JOIN users u ON u.id = p.user_id
     WHERE p.user_id = ? ORDER BY p.created_at DESC`
  ).all(req.params.userId);

  res.json(attachMeta(posts, req.userId));
});

// GET /api/posts/:id - single post
router.get('/:id', optionalAuth, (req, res) => {
  const post = db.prepare(
    `SELECT p.id, p.content, p.image_url, p.created_at,
            u.id AS user_id, u.username, u.display_name, u.avatar_url
     FROM posts p JOIN users u ON u.id = p.user_id WHERE p.id = ?`
  ).get(req.params.id);

  if (!post) return res.status(404).json({ error: 'post not found' });
  res.json(attachMeta([post], req.userId)[0]);
});

// POST /api/posts - create a post
router.post('/', requireAuth, (req, res) => {
  const { content, image_url } = req.body;
  if (!content || !content.trim()) {
    return res.status(400).json({ error: 'content is required' });
  }

  const result = db.prepare(
    'INSERT INTO posts (user_id, content, image_url) VALUES (?, ?, ?)'
  ).run(req.userId, content.trim(), image_url || '');

  const post = db.prepare(
    `SELECT p.id, p.content, p.image_url, p.created_at,
            u.id AS user_id, u.username, u.display_name, u.avatar_url
     FROM posts p JOIN users u ON u.id = p.user_id WHERE p.id = ?`
  ).get(result.lastInsertRowid);

  res.status(201).json(attachMeta([post], req.userId)[0]);
});

// DELETE /api/posts/:id - delete own post
router.delete('/:id', requireAuth, (req, res) => {
  const post = db.prepare('SELECT * FROM posts WHERE id = ?').get(req.params.id);
  if (!post) return res.status(404).json({ error: 'post not found' });
  if (post.user_id !== req.userId) {
    return res.status(403).json({ error: 'not your post' });
  }

  db.prepare('DELETE FROM posts WHERE id = ?').run(req.params.id);
  res.json({ deleted: true });
});

// POST /api/posts/:id/like
router.post('/:id/like', requireAuth, (req, res) => {
  const post = db.prepare('SELECT id FROM posts WHERE id = ?').get(req.params.id);
  if (!post) return res.status(404).json({ error: 'post not found' });

  try {
    db.prepare('INSERT INTO likes (post_id, user_id) VALUES (?, ?)')
      .run(req.params.id, req.userId);
  } catch (err) {
    return res.status(409).json({ error: 'already liked' });
  }

  res.status(201).json({ liked: true });
});

// DELETE /api/posts/:id/like
router.delete('/:id/like', requireAuth, (req, res) => {
  const result = db.prepare(
    'DELETE FROM likes WHERE post_id = ? AND user_id = ?'
  ).run(req.params.id, req.userId);

  if (result.changes === 0) {
    return res.status(404).json({ error: 'not liked yet' });
  }
  res.json({ liked: false });
});

module.exports = router;
