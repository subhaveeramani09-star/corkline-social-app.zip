const API = '/api';

const state = {
  token: localStorage.getItem('token') || null,
  user: JSON.parse(localStorage.getItem('user') || 'null'),
  view: 'feed',
  selectedPostId: null,
  selectedProfileId: null,
};

// ---------- helpers ----------
function authHeaders() {
  return state.token ? { Authorization: `Bearer ${state.token}` } : {};
}

async function api(path, options = {}) {
  const res = await fetch(`${API}${path}`, {
    ...options,
    headers: {
      'Content-Type': 'application/json',
      ...authHeaders(),
      ...(options.headers || {}),
    },
    body: options.body ? JSON.stringify(options.body) : undefined,
  });

  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(data.error || 'Something went wrong');
  return data;
}

function initials(name) {
  if (!name) return '?';
  return name.trim().split(/\s+/).slice(0, 2).map(w => w[0].toUpperCase()).join('');
}

function avatarHTML(user, size = '') {
  if (user.avatar_url) {
    return `<div class="avatar" style="background-image:url('${escapeAttr(user.avatar_url)}')"></div>`;
  }
  return `<div class="avatar">${initials(user.display_name || user.username)}</div>`;
}

function escapeHTML(str = '') {
  return str.replace(/[&<>"']/g, c => ({
    '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;'
  }[c]));
}
function escapeAttr(str = '') { return escapeHTML(str); }

function timeAgo(iso) {
  const then = new Date(iso.replace(' ', 'T') + 'Z');
  const diff = (Date.now() - then.getTime()) / 1000;
  if (diff < 60) return 'just now';
  if (diff < 3600) return `${Math.floor(diff / 60)}m ago`;
  if (diff < 86400) return `${Math.floor(diff / 3600)}h ago`;
  return `${Math.floor(diff / 86400)}d ago`;
}

function setAuth(token, user) {
  state.token = token;
  state.user = user;
  localStorage.setItem('token', token);
  localStorage.setItem('user', JSON.stringify(user));
}

function clearAuth() {
  state.token = null;
  state.user = null;
  localStorage.removeItem('token');
  localStorage.removeItem('user');
}

// ---------- auth screen ----------
const authScreen = document.getElementById('auth-screen');
const appScreen = document.getElementById('app-screen');

document.querySelectorAll('.auth-tab').forEach(tab => {
  tab.addEventListener('click', () => {
    document.querySelectorAll('.auth-tab').forEach(t => t.classList.remove('active'));
    tab.classList.add('active');
    const target = tab.dataset.tab;
    document.getElementById('login-form').classList.toggle('hidden', target !== 'login');
    document.getElementById('register-form').classList.toggle('hidden', target !== 'register');
  });
});

document.getElementById('login-form').addEventListener('submit', async (e) => {
  e.preventDefault();
  const form = e.target;
  const errorEl = document.getElementById('login-error');
  errorEl.textContent = '';
  try {
    const data = await api('/auth/login', {
      method: 'POST',
      body: {
        username: form.username.value.trim(),
        password: form.password.value,
      },
    });
    setAuth(data.token, data.user);
    enterApp();
  } catch (err) {
    errorEl.textContent = err.message;
  }
});

document.getElementById('register-form').addEventListener('submit', async (e) => {
  e.preventDefault();
  const form = e.target;
  const errorEl = document.getElementById('register-error');
  errorEl.textContent = '';
  try {
    const data = await api('/auth/register', {
      method: 'POST',
      body: {
        display_name: form.display_name.value.trim(),
        username: form.username.value.trim(),
        email: form.email.value.trim(),
        password: form.password.value,
      },
    });
    setAuth(data.token, data.user);
    enterApp();
  } catch (err) {
    errorEl.textContent = err.message;
  }
});

document.getElementById('logout-btn').addEventListener('click', () => {
  clearAuth();
  location.reload();
});

// ---------- navigation ----------
document.querySelectorAll('.nav-btn').forEach(btn => {
  btn.addEventListener('click', () => {
    document.querySelectorAll('.nav-btn').forEach(b => b.classList.remove('active'));
    btn.classList.add('active');
    state.view = btn.dataset.view;
    if (state.view === 'profile') {
      state.selectedProfileId = state.user.id;
      showProfileDetail(state.user.id);
    }
    loadFeed();
  });
});

// ---------- composer ----------
document.getElementById('composer').addEventListener('submit', async (e) => {
  e.preventDefault();
  const input = document.getElementById('composer-input');
  const imageInput = document.getElementById('composer-image');
  const content = input.value.trim();
  if (!content) return;

  try {
    await api('/posts', {
      method: 'POST',
      body: { content, image_url: imageInput.value.trim() },
    });
    input.value = '';
    imageInput.value = '';
    loadFeed();
    refreshMiniProfile();
  } catch (err) {
    alert(err.message);
  }
});

// ---------- feed ----------
async function loadFeed() {
  const feedList = document.getElementById('feed-list');
  feedList.innerHTML = `<div class="empty-state">Loading the board...</div>`;

  try {
    let posts;
    if (state.view === 'following') {
      posts = await api('/posts?feed=following');
    } else if (state.view === 'profile') {
      posts = await api(`/posts/user/${state.selectedProfileId}`);
    } else {
      posts = await api('/posts');
    }
    renderFeed(posts);
  } catch (err) {
    feedList.innerHTML = `<div class="empty-state">${escapeHTML(err.message)}</div>`;
  }
}

function renderFeed(posts) {
  const feedList = document.getElementById('feed-list');
  if (!posts.length) {
    feedList.innerHTML = `<div class="empty-state">Nothing pinned here yet.</div>`;
    return;
  }

  feedList.innerHTML = posts.map(post => `
    <article class="card post-card ${post.id === state.selectedPostId ? 'selected' : ''}" data-post-id="${post.id}">
      <div class="pin"></div>
      <div class="post-head" data-user-id="${post.user_id}">
        ${avatarHTML(post)}
        <div>
          <span class="post-author">${escapeHTML(post.display_name || post.username)}</span>
          <span class="handle">@${escapeHTML(post.username)}</span>
        </div>
        <span class="post-time">${timeAgo(post.created_at)}</span>
      </div>
      <p class="post-content">${escapeHTML(post.content)}</p>
      ${post.image_url ? `<img class="post-image" src="${escapeAttr(post.image_url)}" alt="" />` : ''}
      <div class="post-actions">
        <button class="action-btn like-btn ${post.likedByMe ? 'liked' : ''}" data-post-id="${post.id}">
          <span class="icon">${post.likedByMe ? '♥' : '♡'}</span> ${post.likeCount}
        </button>
        <button class="action-btn comment-open-btn" data-post-id="${post.id}">
          <span class="icon">✎</span> ${post.commentCount}
        </button>
      </div>
    </article>
  `).join('');

  feedList.querySelectorAll('.like-btn').forEach(btn => {
    btn.addEventListener('click', (e) => { e.stopPropagation(); toggleLike(btn); });
  });
  feedList.querySelectorAll('.comment-open-btn').forEach(btn => {
    btn.addEventListener('click', (e) => { e.stopPropagation(); showThread(btn.dataset.postId); });
  });
  feedList.querySelectorAll('.post-head').forEach(head => {
    head.addEventListener('click', (e) => {
      e.stopPropagation();
      showProfileDetail(head.dataset.userId);
    });
  });
  feedList.querySelectorAll('.post-card').forEach(card => {
    card.addEventListener('click', () => showThread(card.dataset.postId));
  });
}

async function toggleLike(btn) {
  const postId = btn.dataset.postId;
  const liked = btn.classList.contains('liked');
  try {
    if (liked) {
      await api(`/posts/${postId}/like`, { method: 'DELETE' });
    } else {
      await api(`/posts/${postId}/like`, { method: 'POST' });
    }
    loadFeed();
    if (state.selectedPostId == postId) showThread(postId);
  } catch (err) {
    alert(err.message);
  }
}

// ---------- thread (post + comments) detail ----------
async function showThread(postId) {
  state.selectedPostId = Number(postId);
  const detail = document.getElementById('detail-col');
  detail.innerHTML = `<div class="empty-hint">Loading thread...</div>`;

  try {
    const [post, comments] = await Promise.all([
      api(`/posts/${postId}`),
      api(`/posts/${postId}/comments`),
    ]);

    detail.innerHTML = `
      <div class="thread-post card">
        <div class="pin"></div>
        <div class="post-head" data-user-id="${post.user_id}">
          ${avatarHTML(post)}
          <div>
            <span class="post-author">${escapeHTML(post.display_name || post.username)}</span>
            <span class="handle">@${escapeHTML(post.username)}</span>
          </div>
          <span class="post-time">${timeAgo(post.created_at)}</span>
        </div>
        <p class="post-content">${escapeHTML(post.content)}</p>
        ${post.image_url ? `<img class="post-image" src="${escapeAttr(post.image_url)}" alt="" />` : ''}
        <div class="post-actions">
          <button class="action-btn like-btn ${post.likedByMe ? 'liked' : ''}" data-post-id="${post.id}">
            <span class="icon">${post.likedByMe ? '♥' : '♡'}</span> ${post.likeCount}
          </button>
          <span class="action-btn"><span class="icon">✎</span> ${post.commentCount}</span>
          ${post.user_id === state.user.id ? `<button class="action-btn delete-post-btn" data-post-id="${post.id}">Delete</button>` : ''}
        </div>
      </div>

      <div class="thread-line">
        ${comments.map(c => `
          <div class="comment">
            <div class="comment-head">
              ${avatarHTML(c)}
              <span class="comment-author">${escapeHTML(c.display_name || c.username)}</span>
              <span class="comment-time">${timeAgo(c.created_at)}</span>
            </div>
            <p class="comment-content">${escapeHTML(c.content)}</p>
          </div>
        `).join('') || '<p class="empty-hint">No replies yet. Start the thread.</p>'}
      </div>

      <form class="comment-form" id="comment-form">
        <input type="text" id="comment-input" placeholder="Add a reply..." maxlength="300" />
        <button type="submit" class="btn btn-primary btn-small">Reply</button>
      </form>
    `;

    detail.querySelector('.like-btn').addEventListener('click', () => toggleLike(detail.querySelector('.like-btn')));
    detail.querySelector('.post-head').addEventListener('click', () => showProfileDetail(post.user_id));

    const deleteBtn = detail.querySelector('.delete-post-btn');
    if (deleteBtn) {
      deleteBtn.addEventListener('click', async () => {
        if (!confirm('Delete this post?')) return;
        await api(`/posts/${postId}`, { method: 'DELETE' });
        state.selectedPostId = null;
        detail.innerHTML = `<div class="empty-hint">Select a post or profile to see the thread here.</div>`;
        loadFeed();
      });
    }

    document.getElementById('comment-form').addEventListener('submit', async (e) => {
      e.preventDefault();
      const input = document.getElementById('comment-input');
      const content = input.value.trim();
      if (!content) return;
      try {
        await api(`/posts/${postId}/comments`, { method: 'POST', body: { content } });
        input.value = '';
        showThread(postId);
        loadFeed();
      } catch (err) {
        alert(err.message);
      }
    });
  } catch (err) {
    detail.innerHTML = `<div class="empty-hint">${escapeHTML(err.message)}</div>`;
  }
}

// ---------- profile detail (right panel, for viewing others) ----------
async function showProfileDetail(userId) {
  state.selectedProfileId = Number(userId);
  const detail = document.getElementById('detail-col');
  detail.innerHTML = `<div class="empty-hint">Loading profile...</div>`;

  try {
    const profile = await api(`/users/${userId}`);
    const isMe = profile.id === state.user.id;

    detail.innerHTML = `
      <div class="card profile-view">
        <div class="pin"></div>
        ${avatarHTML(profile)}
        <h3>${escapeHTML(profile.display_name || profile.username)}</h3>
        <p class="handle">@${escapeHTML(profile.username)}</p>
        <p class="bio">${escapeHTML(profile.bio || '')}</p>
        <div class="stat-row">
          <div><strong>${profile.followerCount}</strong><span>followers</span></div>
          <div><strong>${profile.followingCount}</strong><span>following</span></div>
          <div><strong>${profile.postCount}</strong><span>posts</span></div>
        </div>
        ${!isMe ? `
          <button class="btn ${profile.isFollowing ? 'btn-outline' : 'btn-primary'} follow-btn" data-user-id="${profile.id}">
            ${profile.isFollowing ? 'Following' : 'Follow'}
          </button>` : ''}
      </div>
    `;

    if (!isMe) {
      detail.querySelector('.follow-btn').addEventListener('click', async (e) => {
        const btn = e.target;
        try {
          if (profile.isFollowing) {
            await api(`/users/${profile.id}/follow`, { method: 'DELETE' });
          } else {
            await api(`/users/${profile.id}/follow`, { method: 'POST' });
          }
          showProfileDetail(userId);
        } catch (err) {
          alert(err.message);
        }
      });
    }

    // Also filter feed to this user's posts if viewing their profile via profile nav
    if (state.view === 'profile' && isMe) {
      loadFeed();
    }
  } catch (err) {
    detail.innerHTML = `<div class="empty-hint">${escapeHTML(err.message)}</div>`;
  }
}

// ---------- mini profile sidebar ----------
async function refreshMiniProfile() {
  const profile = await api(`/users/${state.user.id}`);
  const avatarEl = document.getElementById('me-avatar');
  if (profile.avatar_url) {
    avatarEl.style.backgroundImage = `url('${profile.avatar_url}')`;
    avatarEl.textContent = '';
  } else {
    avatarEl.style.backgroundImage = '';
    avatarEl.textContent = initials(profile.display_name || profile.username);
  }
  document.getElementById('me-name').textContent = profile.display_name || profile.username;
  document.getElementById('me-handle').textContent = `@${profile.username}`;
  document.getElementById('me-bio').textContent = profile.bio || '';
  document.getElementById('me-followers').textContent = profile.followerCount;
  document.getElementById('me-following').textContent = profile.followingCount;
  document.getElementById('me-posts').textContent = profile.postCount;
}

// ---------- edit profile modal ----------
const editModal = document.getElementById('edit-modal');
document.getElementById('edit-profile-btn').addEventListener('click', () => {
  document.getElementById('edit-display-name').value = state.user.display_name || '';
  document.getElementById('edit-bio').value = state.user.bio || '';
  document.getElementById('edit-avatar').value = state.user.avatar_url || '';
  editModal.classList.remove('hidden');
});
document.getElementById('edit-cancel').addEventListener('click', () => editModal.classList.add('hidden'));
document.getElementById('edit-form').addEventListener('submit', async (e) => {
  e.preventDefault();
  try {
    const updated = await api('/users/me', {
      method: 'PUT',
      body: {
        display_name: document.getElementById('edit-display-name').value.trim(),
        bio: document.getElementById('edit-bio').value.trim(),
        avatar_url: document.getElementById('edit-avatar').value.trim(),
      },
    });
    state.user = { ...state.user, ...updated };
    localStorage.setItem('user', JSON.stringify(state.user));
    editModal.classList.add('hidden');
    refreshMiniProfile();
  } catch (err) {
    alert(err.message);
  }
});

// ---------- boot ----------
function enterApp() {
  authScreen.classList.add('hidden');
  appScreen.classList.remove('hidden');
  document.getElementById('nav-my-profile').dataset.view = 'profile';
  refreshMiniProfile();
  loadFeed();
}

if (state.token && state.user) {
  enterApp();
}
